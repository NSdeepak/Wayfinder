
/*TO VIEW TEMPLE, HOTEL AND RESTAURAUNT BY THE RESPECTIVE BUTTONS*/

const allButton = document.getElementById("wayfinder_search_button_all");
const templeButton = document.getElementById('wayfinder_search_button_temple');
const hotelButton = document.getElementById('wayfinder_search_button_hotel');
const restarauntButton = document.getElementById('wayfinder_search_button_restaraunt');

const allResults = document.getElementById('all');
const templeResults = document.getElementById('temple');
const hotelResults = document.getElementById('hotel');
const restarauntResults = document.getElementById('restaraunt');

/*TO VIEW ALL THE DETAILS*/

function all(){
    allResults.style.display = 'block';
    hotelResults.style.display = 'none';
    templeResults.style.display = 'none';
    restarauntResults.style.display = 'none';
}

/*TO VIEW THE TEMPLE BY CLICKING THE ABOVE TEMPLE BUTTON*/

function temple(){
    allResults.style.display = 'none';
    hotelResults.style.display = 'none';
    templeResults.style.display = 'block';
    restarauntResults.style.display = 'none';
}

/*TO VIEW THE HOTEL BY CLICKING THE ABOVE HOTEL BUTTON*/

function hotel(){
    allResults.style.display = 'none';
    templeResults.style.display = 'none';
    restarauntResults.style.display = 'none';
    hotelResults.style.display = 'block';
}

/*TO VIEW THE RESTAURANT BY CLICKING THE ABOVE RESTAURANT BUTTON*/

function restaraunt(){
    allResults.style.display = 'none';
    templeResults.style.display = 'none';
    hotelResults.style.display = 'none';
    restarauntResults.style.display = 'block';
}

allButton.addEventListener("click", all);
templeButton.addEventListener("click", temple);
hotelButton.addEventListener("click", hotel);
restarauntButton.addEventListener("click", restaraunt);